﻿namespace hangman
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gameNameWelcome = new System.Windows.Forms.Label();
            this.hangmanPics = new System.Windows.Forms.GroupBox();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ipucuButton = new System.Windows.Forms.Button();
            this.kelimeUzunluguLabel = new System.Windows.Forms.Label();
            this.yanlisTahminlerLabel = new System.Windows.Forms.Label();
            this.userGuessTextbox = new System.Windows.Forms.TextBox();
            this.pointLabel1 = new System.Windows.Forms.Label();
            this.hangmanPictureBox1 = new System.Windows.Forms.PictureBox();
            this.hangmanPics.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hangmanPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gameNameWelcome
            // 
            this.gameNameWelcome.AutoSize = true;
            this.gameNameWelcome.BackColor = System.Drawing.Color.Transparent;
            this.gameNameWelcome.Font = new System.Drawing.Font("Cambria", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.gameNameWelcome.Location = new System.Drawing.Point(393, 9);
            this.gameNameWelcome.Name = "gameNameWelcome";
            this.gameNameWelcome.Size = new System.Drawing.Size(174, 37);
            this.gameNameWelcome.TabIndex = 1;
            this.gameNameWelcome.Text = "HANGMAN";
            // 
            // hangmanPics
            // 
            this.hangmanPics.Controls.Add(this.hangmanPictureBox1);
            this.hangmanPics.Location = new System.Drawing.Point(508, 59);
            this.hangmanPics.Name = "hangmanPics";
            this.hangmanPics.Size = new System.Drawing.Size(410, 418);
            this.hangmanPics.TabIndex = 3;
            this.hangmanPics.TabStop = false;
            // 
            // ımageList1
            // 
            this.ımageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.ımageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(114, 337);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "Tahmin et";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pointLabel1);
            this.groupBox1.Controls.Add(this.ipucuButton);
            this.groupBox1.Controls.Add(this.kelimeUzunluguLabel);
            this.groupBox1.Controls.Add(this.yanlisTahminlerLabel);
            this.groupBox1.Controls.Add(this.userGuessTextbox);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(30, 59);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(469, 417);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // ipucuButton
            // 
            this.ipucuButton.Location = new System.Drawing.Point(301, 181);
            this.ipucuButton.Name = "ipucuButton";
            this.ipucuButton.Size = new System.Drawing.Size(75, 23);
            this.ipucuButton.TabIndex = 4;
            this.ipucuButton.Text = "İpucu";
            this.ipucuButton.UseVisualStyleBackColor = true;
            this.ipucuButton.Click += new System.EventHandler(this.ipucuButton_Click);
            // 
            // kelimeUzunluguLabel
            // 
            this.kelimeUzunluguLabel.AutoSize = true;
            this.kelimeUzunluguLabel.Location = new System.Drawing.Point(48, 181);
            this.kelimeUzunluguLabel.Name = "kelimeUzunluguLabel";
            this.kelimeUzunluguLabel.Size = new System.Drawing.Size(92, 13);
            this.kelimeUzunluguLabel.TabIndex = 3;
            this.kelimeUzunluguLabel.Text = "Kelime Uzunluğu: ";
            // 
            // yanlisTahminlerLabel
            // 
            this.yanlisTahminlerLabel.AutoSize = true;
            this.yanlisTahminlerLabel.Location = new System.Drawing.Point(48, 208);
            this.yanlisTahminlerLabel.Name = "yanlisTahminlerLabel";
            this.yanlisTahminlerLabel.Size = new System.Drawing.Size(90, 13);
            this.yanlisTahminlerLabel.TabIndex = 2;
            this.yanlisTahminlerLabel.Text = "Yanlış Tahminler: ";
            // 
            // userGuessTextbox
            // 
            this.userGuessTextbox.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.userGuessTextbox.Location = new System.Drawing.Point(51, 337);
            this.userGuessTextbox.Name = "userGuessTextbox";
            this.userGuessTextbox.Size = new System.Drawing.Size(46, 32);
            this.userGuessTextbox.TabIndex = 1;
            // 
            // pointLabel1
            // 
            this.pointLabel1.AutoSize = true;
            this.pointLabel1.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pointLabel1.Location = new System.Drawing.Point(48, 277);
            this.pointLabel1.Name = "pointLabel1";
            this.pointLabel1.Size = new System.Drawing.Size(130, 24);
            this.pointLabel1.TabIndex = 5;
            this.pointLabel1.Text = "PUAN: 100P";
            // 
            // hangmanPictureBox1
            // 
            this.hangmanPictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.hangmanPictureBox1.Location = new System.Drawing.Point(6, 38);
            this.hangmanPictureBox1.Name = "hangmanPictureBox1";
            this.hangmanPictureBox1.Size = new System.Drawing.Size(398, 263);
            this.hangmanPictureBox1.TabIndex = 0;
            this.hangmanPictureBox1.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(944, 501);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.hangmanPics);
            this.Controls.Add(this.gameNameWelcome);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.hangmanPics.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hangmanPictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gameNameWelcome;
        private System.Windows.Forms.GroupBox hangmanPics;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox userGuessTextbox;
        private System.Windows.Forms.Label kelimeUzunluguLabel;
        private System.Windows.Forms.Label yanlisTahminlerLabel;
        private System.Windows.Forms.Button ipucuButton;
        private System.Windows.Forms.Label pointLabel1;
        private System.Windows.Forms.PictureBox hangmanPictureBox1;
    }
}