﻿namespace hangman
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.gameNameWelcome = new System.Windows.Forms.Label();
            this.gameStartButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // gameNameWelcome
            // 
            this.gameNameWelcome.AutoSize = true;
            this.gameNameWelcome.BackColor = System.Drawing.Color.Transparent;
            this.gameNameWelcome.Font = new System.Drawing.Font("Cambria", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.gameNameWelcome.Location = new System.Drawing.Point(350, 300);
            this.gameNameWelcome.Name = "gameNameWelcome";
            this.gameNameWelcome.Size = new System.Drawing.Size(260, 57);
            this.gameNameWelcome.TabIndex = 0;
            this.gameNameWelcome.Text = "HANGMAN";
            // 
            // gameStartButton
            // 
            this.gameStartButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.gameStartButton.Font = new System.Drawing.Font("Cambria", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.gameStartButton.Location = new System.Drawing.Point(400, 360);
            this.gameStartButton.Name = "gameStartButton";
            this.gameStartButton.Size = new System.Drawing.Size(160, 50);
            this.gameStartButton.TabIndex = 1;
            this.gameStartButton.Text = "BAŞLA";
            this.gameStartButton.UseVisualStyleBackColor = false;
            this.gameStartButton.Click += new System.EventHandler(this.gameStartButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(944, 561);
            this.Controls.Add(this.gameStartButton);
            this.Controls.Add(this.gameNameWelcome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gameNameWelcome;
        private System.Windows.Forms.Button gameStartButton;
    }
}

