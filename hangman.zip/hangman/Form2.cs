﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hangman
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        string randomWord; //stores the random word
        string randomClue; //stores the random clue
        List<char> guessedLetters = new List<char>(); //stores the letters that the user has guessed
        List<char> wrongGuesses = new List<char>(); //stores the letters that the user has guessed wrong
        int point = 100; //when user guesses a letter wrong, 10 points will be deducted
        int correctGuessCount = 0; //stores the number of correct guesses

        private void Form2_Load(object sender, EventArgs e)
        {
            //when form loads, generate a random word and clue
            List<string> wordAndClue = new List<string>();
            wordAndClue = generateRandomWordandClue();
            randomWord = wordAndClue[0].ToUpper();
            randomClue = wordAndClue[1];
            kelimeUzunluguLabel.Text = "Kelime Uzunluğu: " + randomWord.Length;

            //Create a label for the clue
            int labelX = 40; //initial x position
            int labelY = 60; //y position
            int labelIndex = 0;

            foreach (char letter in randomWord)
            {
                System.Windows.Forms.Label label = new System.Windows.Forms.Label();
                label.Name = "hangmanLabel" + labelIndex;
                labelIndex++;
                label.Text = "_";
                label.Location = new Point(labelX, labelY);
                label.AutoSize = true;
                label.Font = new Font("Arial", 12);
                label.BackColor = Color.Yellow;
                labelX += 20;
                groupBox1.Controls.Add(label);
            }
        }
        

        List<string> generateRandomWordandClue()
        {
            //Create a dictionary of words and their hints
            Dictionary<string, string> words = new Dictionary<string, string>();

            //Add words and hints to the dictionary
            words.Add("apple", "A fruit that is commonly red or green.");
            words.Add("banana", "A fruit that is yellow and is commonly found in tropical regions.");
            words.Add("orange", "A fruit that is orange and is commonly found in tropical regions.");
            words.Add("grape", "A fruit that is small and round and is commonly found in bunches.");
            words.Add("kiwi", "A fruit that is brown and has a fuzzy skin.");
            words.Add("strawberry", "A fruit that is red and has small seeds on the outside.");
            words.Add("watermelon", "A fruit that is green on the outside and red on the inside.");
            words.Add("pineapple", "A fruit that is yellow and has a spiky skin.");
            words.Add("mango", "A fruit that is orange and is commonly found in tropical regions.");
            words.Add("pear", "A fruit that is green or yellow and is commonly found in pairs.");
            words.Add("peach", "A fruit that is orange and has a fuzzy skin.");
            words.Add("cherry", "A fruit that is red and is commonly found in pairs.");
            words.Add("blueberry", "A fruit that is small and round and is commonly found in bunches.");
            words.Add("raspberry", "A fruit that is red and has small seeds on the outside.");
            words.Add("blackberry", "A fruit that is black and has small seeds on the outside.");
            words.Add("apricot", "A fruit that is orange and has a pit in the middle.");


            //generate a random word from the dictionary
            Random random = new Random();
            int randomNumber = random.Next(0, words.Count);
            string randomWord = words.ElementAt(randomNumber).Key;
            string randomClue = words.ElementAt(randomNumber).Value;

            return new List<string> { randomWord, randomClue };
        }

        void setHangmanImage(int wrongGuessCount)
        {
            switch (wrongGuessCount)
            {
                case 1:
                    hangmanPictureBox1.Image = Properties.Resources.man_01;
                    break;
                case 2:
                    hangmanPictureBox1.Image = Properties.Resources.man_02;
                    break;
                case 3:
                    hangmanPictureBox1.Image = Properties.Resources.man_03;
                    break;
                case 4:
                    hangmanPictureBox1.Image = Properties.Resources.man_04;
                    break;
                case 5:
                    hangmanPictureBox1.Image = Properties.Resources.man_05;
                    break;
                case 6:
                    hangmanPictureBox1.Image = Properties.Resources.man_06;
                    break;
                case 7:
                    hangmanPictureBox1.Image = Properties.Resources.man_07;
                    break;
                case 8:
                    hangmanPictureBox1.Image = Properties.Resources.man_08;
                    break;
                case 9:
                    hangmanPictureBox1.Image = Properties.Resources.man_09;
                    break;
                case 10:
                    hangmanPictureBox1.Image = Properties.Resources.man_10;
                    break;
                default:
                    break;
            }
            hangmanPictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }
                

        private void button1_Click(object sender, EventArgs e)
        {
            if(userGuessTextbox.Text == "")
            {
                MessageBox.Show("Lütfen bir harf giriniz.");
                return;
            }
            if(userGuessTextbox.Text.Length > 1)
            {
                MessageBox.Show("Lütfen sadece bir harf giriniz.");
                return;
            }
            if (!char.IsLetter(userGuessTextbox.Text.ToUpper()[0]))
            {
                MessageBox.Show("Lütfen bir harf giriniz.");
                return;
            }
            if (guessedLetters.Contains(userGuessTextbox.Text.ToUpper()[0]))
            {
                MessageBox.Show("Bu harfi zaten tahmin ettiniz.");
                return;
            }
            //add the guessed letter to the list of guessed letters
            guessedLetters.Add(userGuessTextbox.Text.ToUpper()[0]);

            bool found = false;
            for (int i = 0; i < randomWord.Length; i++)
            {
                if (randomWord[i] == userGuessTextbox.Text.ToUpper()[0])
                {
                    groupBox1.Controls["hangmanLabel" + i].Text = userGuessTextbox.Text;
                    correctGuessCount++;
                    found = true;
                }
            }

            if(found == false)
            {
                wrongGuesses.Add(userGuessTextbox.Text.ToUpper()[0]);
                yanlisTahminlerLabel.Text += userGuessTextbox.Text + " ";
                setHangmanImage(wrongGuesses.Count);//set the hangman image according to the number of wrong guesses
                point -= 10; //deduct 10 points for wrong guess
                pointLabel1.Text = "PUAN: " + point + "P";
                if (point == 0)
                {
                    MessageBox.Show("Oyun bitti! Aradığınız kelime: " + randomWord);
                    Application.Exit();
                }
            }

            if(correctGuessCount == randomWord.Length)
            {
                MessageBox.Show("Tebrikler! Kelimeyi doğru tahmin ettiniz.");
                Application.Exit();
            }


            userGuessTextbox.Text = "";
        }

        private void ipucuButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show(randomClue);
        }
    }
}
